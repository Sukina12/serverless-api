'use strict';

const peopleModel = require ('./people.schema');

exports.handler = async (event) => {
  try {
    const id = event.pathParameters ? event.pathParameters.id : null;
     
     let deleteRecord = await peopleModel.delete({id});

    return {
      statusCode :202,
      body : [],
    }
  } catch (error) {
    return {
      statusCode : 500,
      error : error.message,
    }
  }
}
